function [Sknn]=getKnnGraph(S,k)
  [a,~]=size(S);
  Sknn =zeros(a,a);
  for i=1:a
    ind =getKnn(S(i,:), k);
    Sknn(i,ind)=1;
    Sknn(ind,i)=1;
  end